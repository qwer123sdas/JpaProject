package com.example.jpaproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
